import firebase_admin as fba
from firebase_admin import db, credentials
import datetime
FIREBASE_DATABASE_URL ='https://project-90652-default-rtdb.firebaseio.com/'# https://football-f559a.firebaseio.com
creds = credentials.Certificate('info10.json')
data = fba.initialize_app(creds, {'databaseURL': FIREBASE_DATABASE_URL})

iterate = 0
while True:
    CPU_Temp = input('Enter CPU_Temp - ')
    Power_consumption = input('Enter Power_consumption - ')
    Ambient_Temperature = input('Enter Ambient_Temperature - ')
    Humidity = input('Enter Humidity - ')
    date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ref = db.reference(f"/{iterate}")
    ref.set({"CPU_Temp":CPU_Temp,"Power_consumption":Power_consumption
             ,"Ambient_Temperature":Ambient_Temperature,"Humidity":Humidity})
    iterate = iterate+1