import firebase_admin as fba
from firebase_admin import db, credentials
import matplotlib.pyplot as plt
import numpy as np
from twilio.rest import Client
import datetime
FIREBASE_DATABASE_URL ='https://project-90652-default-rtdb.firebaseio.com/'
creds = credentials.Certificate('info10.json')
data = fba.initialize_app(creds, {'databaseURL': FIREBASE_DATABASE_URL})

iterate = 0


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
import datetime



# Load abnormal and normal temperature data
abnormal_data = pd.read_csv('abnormal_temperature.csv')
normal_data = pd.read_csv('normaltemp.csv')

# Combine the datasets
data = pd.concat([abnormal_data, normal_data])

# Create a feature matrix (X) and target variable (y)
X = data[['CPU_Temp', 'Power_consumption(W)', 'Ambient_Temperature', 'Humidity']]
y = data['Target']

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize the feature matrix
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Create and train the MLP classifier
clf = MLPClassifier(hidden_layer_sizes=(10, 5), max_iter=1000, random_state=42)
clf.fit(X_train, y_train)

#testing accuracy
# y_pred=clf.predict(X_test)
# accuracy = accuracy_score(y_test, y_pred)
# print(f"******MODEL ACCURACY: {accuracy}")
def gather_val(threshold=2,samples=10):
  temp_val_plot = []
  v = db.reference("/").order_by_child('temp').limit_to_last(samples).get()
  alert_count = 0
  alert_sent = False

  for value in range(len(v)):
    if value !=0:
      temp_value = v[value]['CPU_Temp']
      power_value = v[value]['Power_consumption']
      ambient_value = v[value]['Ambient_Temperature']
      humidity_value = v[value]['Humidity']
      temp_val_plot.append(temp_value)

      pred_arr = [temp_value,power_value,ambient_value,humidity_value]
      ##
      print(temp_value,"********")#
      print(pred_arr)
      #print(pred_arr,"****")
      pred_arr = [int(numeric_string) for numeric_string in pred_arr]
      prediction = clf.predict(np.asarray(pred_arr).reshape(1,-1))
      if prediction == 'high':
          alert_count += 1
          if alert_count >= threshold and not alert_sent:
              # Send a notification to the owner's mobile (you can use Twilio for this)
              account_sid = 'AC012dcf15682e4d6eb84ebbe0e76d6d33'
              auth_token = '8a30b42a5cc01b6bd9e4b3e81a18ad1d'
              client = Client(account_sid, auth_token)

              # Include the CPU temperature in the alert message
            #  cpu_temp = data.iloc[i]['CPU_Temp']
              cpu_temp= temp_value
             # print("****",X_test[i],"****")
              message = client.messages.create(
                  body=f"High CPU temperature alert! CPU temperature: {cpu_temp}°C",
                  from_="+12295751667",
                  to="+918519815901"
              )

              print(f"High CPU temperature alert sent to the owner's mobile.")
              alert_sent = True  # Mark the alert as sent
      else:
          alert_count = 0
          alert_sent = False

  return temp_val_plot

plot_val= gather_val()
plot_val.sort()
plt.plot(plot_val)
plt.title('Plot of the Given Array')
plt.xlabel('Index')
plt.ylabel('Values')#plt.gca().invert_yaxis()
plt.show()
print(plot_val)